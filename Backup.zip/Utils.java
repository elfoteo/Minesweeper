import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.screen.Screen;

import javax.swing.*;
import java.io.IOException;

public class Utils {
    public static int getMaxStringLength(String[] array) {
        if (array == null || array.length == 0) {
            return 0; // or throw an exception, depending on your requirements
        }

        int maxLength = array[0].length();

        for (String logo : array) {
            int currentLength = logo.length();
            if (currentLength > maxLength) {
                maxLength = currentLength;
            }
        }

        return maxLength;
    }

    public static void Debug(String message){
        JOptionPane.showMessageDialog(null, message);
    }

    public static void WriteDebug(TextGraphics graphics, Screen screen, String string) throws IOException {
        graphics.putString(0, screen.getTerminalSize().getRows()-1, string);
        screen.refresh();
    }

    public static void WriteDebug(TextGraphics graphics, Screen screen, char string) throws IOException {
        graphics.putString(0, screen.getTerminalSize().getRows()-1, string+"");
        screen.refresh();
    }
}
