import com.googlecode.lanterna.SGR;
import com.googlecode.lanterna.TerminalPosition;
import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.graphics.TextGraphics;
import com.googlecode.lanterna.gui2.Button;
import com.googlecode.lanterna.gui2.Label;
import com.googlecode.lanterna.gui2.Panel;
import com.googlecode.lanterna.gui2.*;
import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.screen.Screen;
import com.googlecode.lanterna.screen.TerminalScreen;
import com.googlecode.lanterna.terminal.DefaultTerminalFactory;
import com.googlecode.lanterna.terminal.Terminal;

import java.awt.*;
import java.io.IOException;
import java.util.Random;


/**
 * Minesweeper using java and lanterna
 * 
 * @author Matteo Ciocci
 *
 */
public class Program {
	private static final String[] logo = """
__  __ _                                                  \s
|  \\/  (_)                                                 \s
| \\  / |_ _ __   ___  _____      _____  ___ _ __   ___ _ __\s
| |\\/| | | '_ \\ / _ \\/ __\\ \\ /\\ / / _ \\/ _ \\ '_ \\ / _ \\ '__|
| |  | | | | | |  __/\\__ \\\\ V  V /  __/  __/ |_) |  __/ |  \s
|_|  |_|_|_| |_|\\___||___/ \\_/\\_/ \\___|\\___| .__/ \\___|_|  \s
										| |             \s
										|_|             \s
            """.split("\n");

	private static final String[] menu = new String[] {"Play", "About","Exit"};
	private static int selectedIndex = 0;
	private static boolean running = true;
	private static Terminal terminal;
	private static Screen screen;
	private static MultiWindowTextGUI gui;
	private static BasicWindow mainWindow;
	private static Panel mainPanel;
	private static TextGraphics textGraphics;

	public static void main(String[] args) throws IOException {
		terminal = new DefaultTerminalFactory().createTerminal();
		
		screen = new TerminalScreen(terminal);
		textGraphics = screen.newTextGraphics();
		gui = new MultiWindowTextGUI(screen, TextColor.ANSI.BLACK);
		mainWindow = new BasicWindow();
		mainPanel = new Panel();
		mainWindow.setComponent(mainPanel);
		terminal.setCursorVisible(false);

		gui.addWindow(mainWindow);

		screen.startScreen();
		screen.clear();
		// To not show the panel
		mainWindow.setVisible(false);
		terminal.enterPrivateMode();

		while (running){
			int x = Utils.getMaxStringLength(logo);
			int y = 0;
			for (String logoLine : logo){
				textGraphics.putString(screen.getTerminalSize().getColumns()/2-x/2, y, logoLine);
				y++;
			}
			screen.refresh();

			x = Utils.getMaxStringLength(menu)+2;
			y = logo.length+2;
			int counter = 0;
			for (String menuLine : menu){
				if (selectedIndex == counter){
					textGraphics.putString(screen.getTerminalSize().getColumns()/2-x/2, y, "o "+menuLine);
				}
				else{
					textGraphics.putString(screen.getTerminalSize().getColumns()/2-x/2, y, "- "+menuLine);
				}
				y++;
				counter++;
			}
			screen.refresh();

			KeyStroke choice = screen.readInput();
			if (choice.getKeyType() == KeyType.EOF){
				running = false;
				break;
			}

			if (choice.getKeyType() == KeyType.ArrowDown){
				selectedIndex++;
				if (selectedIndex > menu.length-1){
					selectedIndex = 0;
				}
			}
			else if (choice.getKeyType() == KeyType.ArrowUp){
				selectedIndex--;
				if (selectedIndex < 0){
					selectedIndex = menu.length-1;
				}
			} else if (choice.getKeyType() == KeyType.Enter) {
				switch (menu[selectedIndex]){
					case "Play":
						// TODO: Show play menu
						String username = getUsername();
						boolean playAgain;
						do {
							playAgain = play();
						}
						while (playAgain);
						break;
					case "About":
						showAboutMenu();
						break;
					case "Exit":
						running = false;
						break;
				}
			}
		}

		terminal.exitPrivateMode();
		screen.stopScreen();
		terminal.close();
	}

	private static String getUsername() throws IOException {
		final String[] username = {""};
		MenuPopupWindow window = new MenuPopupWindow(mainPanel);
		Panel container = new Panel();
		Panel textPanel = new Panel(new LinearLayout(Direction.HORIZONTAL));
		Panel buttonsPanel = new Panel(new LinearLayout(Direction.HORIZONTAL));
		textPanel.addComponent(new Label("Username: "));
		TextBox userBox = new TextBox("");
		Button enterButton = new Button("Enter",
				() -> {
					username[0] = "";
					window.close();
				});
		Button cancelButton = new Button("Cancel", window::close);
		textPanel.addComponent(userBox);
		buttonsPanel.addComponent(enterButton);
		buttonsPanel.addComponent(cancelButton);
		container.addComponent(textPanel);
		container.addComponent(buttonsPanel);

		window.setComponent(container);
		window.setPosition(new TerminalPosition(terminal.getTerminalSize().getColumns() / 2 - 12,
				terminal.getTerminalSize().getRows() / 2 - 4));
		gui.addWindowAndWait(window);
		return username[0];
	}

	// Return bool play again
	private static boolean play() throws IOException {
		terminal.setCursorVisible(true);
		screen.clear();
		String title = "Minesweeper";
		textGraphics.putString(screen.getTerminalSize().getColumns() / 2 - title.length() / 2, 0, title);
		screen.refresh();
		Minesweeper minesweeper = new Minesweeper(10, 10, 1);
		String[] field = minesweeper.getFieldAsString().split("\n");
		Rectangle bounds = new Rectangle(
				screen.getTerminalSize().getColumns()/2-Utils.getMaxStringLength(field)/2,
				screen.getTerminalSize().getRows()/2-field.length/2, field[0].length(), field.length);
		int cursorX = screen.getTerminalSize().getColumns()/2-Utils.getMaxStringLength(field)/2;
		int cursorY = screen.getTerminalSize().getRows()/2-field.length/2;
		int trueX = 0;
		int trueY = 0;
		int score = 0;

		boolean running = true;
		final boolean[] playAgain = {false};

		while (running) {
			textGraphics.putString(0, 1, "Score: "+score+("".repeat(terminal.getTerminalSize().getColumns()-("Score: "+score).length())));
			screen.setCursorPosition(new TerminalPosition(cursorX, cursorY));
			field = minesweeper.getFieldAsString().split("\n");
			int x = screen.getTerminalSize().getColumns()/2-Utils.getMaxStringLength(field)/2;
			int y = screen.getTerminalSize().getRows()/2-field.length/2;
			for (String line : field){
				textGraphics.putString(x, y, line);
				y++;
			}
			screen.refresh();
			KeyStroke choice = screen.readInput();

			switch (choice.getKeyType()) {
				case ArrowUp:
					if (bounds.contains(cursorX, cursorY-1)){
						cursorY--;
						trueY--;
					}
					break;
				case ArrowDown:
					if (bounds.contains(cursorX, cursorY+1)){
						cursorY++;
						trueY++;
					}
					break;
				case ArrowLeft:
					if (bounds.contains(cursorX-2, cursorY)) {
						cursorX -= 2;
						trueX--;
					}
					break;
				case ArrowRight:
					if (bounds.contains(cursorX+2, cursorY)) {
						cursorX += 2;
						trueX++;
					}
					break;
				case Enter:
					Tuple<Character, Tuple<Integer, Boolean>> minedTile = minesweeper.uncover(trueX, trueY);
					// Character: the character that got mined
					// Integer: score
					// Boolean: player has won (game ended)

					// if the game ended
					if (minedTile.second().second()) {
						// Player has won
						// Add the score
						score += minedTile.second().first();
						// Show popup
						MenuPopupWindow window = new MenuPopupWindow(mainPanel);

						// Close button
						Button exitButton = new Button("Exit", window::close);

						Button playAgainButton = new Button("Play Again",
								() -> {
									playAgain[0] = true;
									window.close();
								});

						Label textBox = new Label(String.format("Congratulations! You've successfully cleared the minefield!\nScore: %d\nPress \"Play Again\" to play again or \"Exit\" to exit", score));

						Panel panel = new Panel();
						Panel buttonsPanel = new Panel(new LinearLayout(Direction.HORIZONTAL));
						exitButton.setPosition(new TerminalPosition(0, 5));
						buttonsPanel.addComponent(exitButton);
						buttonsPanel.addComponent(playAgainButton);
						panel.addComponent(textBox);
						panel.addComponent(buttonsPanel);

						// Window can hold only one component, we add a panel to hold everything
						window.setComponent(panel);
						window.setPosition(new TerminalPosition(terminal.getTerminalSize().getColumns() / 2 - 35,
								terminal.getTerminalSize().getRows() / 2 - 4));
						gui.addWindowAndWait(window);

						running = false;
					}
					else if (minedTile.first() == '*') {
						// Player has lost
                        // Show popup
						MenuPopupWindow window = new MenuPopupWindow(mainPanel);


                        // Close button
                        Button exitButton = new Button("Exit", window::close);

                        Button playAgainButton = new Button("Play Again",
								() -> {
									playAgain[0] = true;
									window.close();
								});
                        Label textBox = new Label(String.format("Oh no! You've uncovered a mine!\nScore: %d\nPress \"Play Again\" to play again or \"Exit\" to exit", score));
                        Panel panel = new Panel();
                        Panel buttonsPanel = new Panel(new LinearLayout(Direction.HORIZONTAL));
						exitButton.setPosition(new TerminalPosition(0, 5));
                        buttonsPanel.addComponent(exitButton);
                        buttonsPanel.addComponent(playAgainButton);
                        panel.addComponent(textBox);
                        panel.addComponent(buttonsPanel);


                        // Window can hold only one component, we add a panel to hold everything
                        window.setComponent(panel);
                        window.setPosition(new TerminalPosition(terminal.getTerminalSize().getColumns()/2-25,
								terminal.getTerminalSize().getRows()/2-4));
						gui.addWindowAndWait(window);

                        running = false;
                    } else {// if the tile wasn't already mined
						score += minedTile.second().first();
                    }
					break;
				case EOF, Escape:
					running = false;
					break;
            }

		}
		screen.setCursorPosition(new TerminalPosition(0, 0));
		screen.clear();
		return playAgain[0];
	}

	public static void showAboutMenu() throws IOException {
		screen.clear();

		// Center the "About" title
		String title = "About";
		textGraphics.putString(screen.getTerminalSize().getColumns() / 2 - title.length() / 2, 0, title);

		// Display information about the game and the developer
		textGraphics.putString(0, 2, "Welcome to Minesweeper, a console-based game.");
		textGraphics.putString(0, 3, "This game was coded by Matteo Ciocci as a school project.");

		// Provide instructions on how to navigate menus
		textGraphics.putString(0, 5, "How to navigate menus:");
		textGraphics.putString(0, 6, " - Use the arrow keys to move up and down.");
		textGraphics.putString(0, 7, " - Press the Enter key to choose an option.");
		textGraphics.putString(0, 8, " - To exit a menu, press Escape.");

		// Provide instructions on how to play
		textGraphics.putString(0, 10, "How to play:");
		textGraphics.putString(0, 11, " - Navigate the grid with the 4 arrow keys.");
		textGraphics.putString(0, 12, " - Press Enter to select a cell.");

		// Display the information
		screen.refresh();

		// Wait for Escape key to exit
		while (true) {
			KeyStroke choice = screen.readInput();
			if (choice.getKeyType() == KeyType.Escape) {
				break;
			}
		}
		screen.clear();
	}



	public static class Minesweeper {
		private char[][] matrix;
		private boolean[][] uncovered;
		private static final Random random = new Random();

		Minesweeper(int width, int height, int mines) {
			matrix = new char[width][height];
			uncovered = new boolean[width][height];
			// Initialize the matrix and uncovered arrays
			for (int x = 0; x < width; x++) {
				for (int y = 0; y < height; y++) {
					matrix[x][y] = ' ';
					uncovered[x][y] = false;
				}
			}

			// Place mines randomly on the matrix

			for (int i = 0; i < mines; i++) {
				int randomX, randomY;

				do {
					randomX = random.nextInt(0, width);
					randomY = random.nextInt(0, height);

				} while (matrix[randomX][randomY] == '*');

				matrix[randomX][randomY] = '*';
			}

			// Place numbers
			for (int x = 0; x < width; x++) {
				for (int y = 0; y < height; y++) {
					int adjacentMines = getNumbersOfMines(x, y);
					if (adjacentMines != 0){
						matrix[x][y] = (char)(adjacentMines + '0');
					}
				}
			}
		}


		public String getFieldAsString() {
			StringBuilder res = new StringBuilder();


			for (int x = 0; x < matrix.length; x++) {
				for (int y = 0; y < matrix[0].length; y++) {
					if (uncovered[x][y]) {
						res.append(matrix[x][y]);
					} else {
						res.append("#");
					}
					// Add extra space at the end
					if (matrix[0].length-1 != y){
						res.append(" ");
					}
				}
				res.append("\n");  // Append newline after each row
			}

			return res.toString();
		}

		public Tuple<Character, Tuple<Integer, Boolean>> uncover(int x, int y) {
			boolean wasUncovered = false;
			char cellValue = 'X';
			int score = 0;
			boolean gameEnded = true;

			try {
				wasUncovered = uncovered[y][x];
				uncovered[y][x] = true;
				cellValue = matrix[y][x];
				// If the cell wasn't already uncovered
				if (!wasUncovered){
					score++;

					if (cellValue == ' ') {
						// Check and uncover adjacent cells recursively
						score += uncoverAdjacent(x - 1, y);
						score += uncoverAdjacent(x + 1, y);
						score += uncoverAdjacent(x, y - 1);
						score += uncoverAdjacent(x, y + 1);
					}
				}

				for (x = 0; x < matrix.length; x++) {
					for (y = 0; y < matrix[0].length; y++) {
						if (!uncovered[x][y] && matrix[x][y] != '*'){
							gameEnded = false;
							break;
						}
					}
					if (!gameEnded){
						break;
					}
				}
			} catch (ArrayIndexOutOfBoundsException ignore) {
				// Handle array index out of bounds exception
			}

			return new Tuple<>(cellValue, new Tuple<>(score, gameEnded));
		}

		private int uncoverAdjacent(int x, int y) {
			try {
				if (!uncovered[y][x] && matrix[y][x] != '*') {
					return uncover(x, y).second().first();
				}
			} catch (ArrayIndexOutOfBoundsException ignore) {}
			return 0;
		}

		private boolean isMine(int x, int y){
			try{
				return matrix[x][y] == '*';
			}
			catch (ArrayIndexOutOfBoundsException ignore){

			}
			return false;
		}

		private int getNumbersOfMines(int x, int y){
			int num = 0;
			if (isMine(x-1, y)){
				num++;
			}
			if (isMine(x+1, y)){
				num++;
			}
			if (isMine(x, y-1)){
				num++;
			}
			if (isMine(x, y+1)){
				num++;
			}
			if (isMine(x-1, y-1)){
				num++;
			}
			if (isMine(x+1, y-1)){
				num++;
			}
			if (isMine(x-1, y+1)){
				num++;
			}
			if (isMine(x+1, y+1)){
				num++;
			}
			return num;
		}
	}

}